from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.
def home(request):
    return HttpResponse(
        '<!DOCTYPE html> <html lang="en"> <head><meta charset="UTF-8"> <title>navbar</title> </head> <body>  <nav> <a href="/about/">about</a> <a href="/">contact</a>  <a href="/home">Home</a> </nav> <h1> Welcome to home Page </h1> </body></html>')


# def templatecontact(request):
#     email = request.GET['email']
#     return render(request, 'contactUs.html', {'email': email})
def contact(request):
    return render(request, 'contactUs.html')


def validate(request):
    if request.method == 'POST':
        username = request.POST["user"]
        message = request.POST["message"]
        dict = {
            'username': username,
            'message': message
        }
        return render(request, 'validate.html', dict)
def templateabout(request):
    return render(request, 'about.html')


def navbar(request):
    return render(request, 'navbar.html')
